Hi there 👋,

This repository contains the source code from:

- [Spring for GraphQL Introduction Tutorial](https://www.youtube.com/watch?v=l-7JqCzVMJw)
- [OpenTelemetry Collector Example - Java Agent Spring Boot Docker](https://www.youtube.com/watch?v=-ioJQGLWZok)

Have a good day!

Philip
