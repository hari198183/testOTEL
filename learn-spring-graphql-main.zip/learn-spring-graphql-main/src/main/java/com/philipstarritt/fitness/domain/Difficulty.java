package com.philipstarritt.fitness.domain;

public enum Difficulty {
    BEGINNER,
    ADVANCED
}
